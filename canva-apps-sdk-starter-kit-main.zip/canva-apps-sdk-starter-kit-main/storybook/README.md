# @canva/app-ui-kit Storybook

This directory is a self contained project which runs Storybook. It can be used to discover the components exported by `@canva/app-ui-kit`.

## Setup steps

- Install the dependancies for the project
  ```
  cd storybook
  npm install
  ```
- Run storybook
  ```
  npm run storybook
  ```
