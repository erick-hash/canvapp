const asset = window.canva.content;
export const upload = asset.upload.bind(asset);
