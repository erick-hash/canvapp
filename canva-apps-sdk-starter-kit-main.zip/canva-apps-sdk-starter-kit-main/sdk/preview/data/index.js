const dataProvider = window.canva.dataProvider;
export const onSelectDataTable = dataProvider.onSelectDataTable.bind(dataProvider);
