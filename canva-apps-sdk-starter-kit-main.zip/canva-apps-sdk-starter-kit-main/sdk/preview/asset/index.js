const asset = window.canva.content;
export const upload = asset.upload.bind(asset);
/** beta */
export const getTemporaryUrl = asset.getTemporaryUrl.bind(asset);
